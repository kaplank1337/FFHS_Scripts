import numpy as np
# Definition der Matrizen
A = np.array([[1, 2],
              [2, 5]])
B = np.array([[, b12],
              [b21, b22]])
# Matrixmultiplikation
C = np.dot(A, B)