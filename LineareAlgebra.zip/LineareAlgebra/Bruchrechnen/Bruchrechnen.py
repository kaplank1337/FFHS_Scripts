import numpy as np

B = (1 / 7) * np.array([
    [5, 1, -1],
    [4, 5, 2],
    [-6, 3, 4]
])

print(f"Gegebene Matrix B:\n{B}\n")
