from sympy import mod_inverse




print(mod_inverse(10, 41))